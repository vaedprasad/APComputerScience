
/**
 * Write a description of class SnowManRunner here.
 * 
 * @author Vaed Prasad
 * @version January 2015
 * 

 */
public class SnowManRunner

    /**
 * Run the main method of this program to run
 * the program
 * 
 */
{
    /**
     * Use this method to run your program
     */
    public static void main (String [] args)
    {
        SnowMan myprogram = new SnowMan();
        myprogram.start();
    }
}
