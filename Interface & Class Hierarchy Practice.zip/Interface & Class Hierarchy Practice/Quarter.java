
/**
 * Write a description of class Quarter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Quarter extends Coin
{
    public Quarter() {
        super();
    }

    public double getAmount() {
        return .25;
    }

    public String toString() {
        return "quarter";
    }
}
