
/**
 * Write a description of class Dime here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Dime extends Coin
{
    public Dime() {
        super();
    }

    public double getAmount() {
        return .10;
    }

    public String toString() {
        return "dime";
    }
}
