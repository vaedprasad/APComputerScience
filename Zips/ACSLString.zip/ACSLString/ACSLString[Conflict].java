import java.util.*;
/**
 * Write a description of class ACSLString here.
 * 
 * @author Vaed Prasad
 */
public class ACSLString
{
    public static void main (String[] args) {
        System.out.print("\fInput sutff");
        Scanner input = new Scanner(System.in);
        
        
        
        
        
    }
    
    
    
}
