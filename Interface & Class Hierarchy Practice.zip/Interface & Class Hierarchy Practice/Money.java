
/**
 * Write a description of interface Money here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Money
{
    public double getAmount();
}
