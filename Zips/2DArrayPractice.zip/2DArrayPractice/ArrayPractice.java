
/**
 * Write a description of class ArrayPractice here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ArrayPractice
{
    /**
     * 
     * Write a method that returns the value of the largest positive element in a 2-D array,
     * or 0 if all its elements are negative:
     * // Returns the value of the largest positive element in
     * //the 2-D array m, or 0, if all its elements are negative
     * 
     * private static double positiveMax(double[][] m)
     * 
     */
    public static double positiveMax(double[][] m) {
        double max = 0;   
        for (int i = 0; i < m.length; i++)
        {
            for (int k = 0; k < m[i].length; k++)
            {
               if (m[i][k] > max)
               max = m[i][k];
            }
        }
        return max;
    }
}
