
public class __SHELL1 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
ABC.main(__bluej_param0);

}}
