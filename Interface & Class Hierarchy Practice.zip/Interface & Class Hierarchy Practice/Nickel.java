
/**
 * Write a description of class Nickel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nickel extends Coin
{
    public Nickel() {
        super();
    }

    public double getAmount() {
        return .05;
    }
    
    public String toString() {
        return "nickel";
    }
}
